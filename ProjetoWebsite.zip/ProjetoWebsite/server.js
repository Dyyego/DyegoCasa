// Importa o módulo Express
const express = require('express');

// Cria uma instância do Express
const app = express();

// Cria uma rota para a URL raiz '/'
app.get('/', (req, res) => {
  // Envia uma resposta para a requisição na rota raiz
  res.send('Olá mundo!');
});

// Inicializa o servidor na porta 3001
app.listen(3001, () => {
  console.log('Servidor online na porta 3001');
});

// Cria uma rota para '/sobre'
app.get('/sobre', (req, res) => {
  res.send('testeS');
});
