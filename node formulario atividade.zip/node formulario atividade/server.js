const express = require('express')
const app = express()
const port = 3000
const exphbs = require('express-handlebars')

// configuração do template handlebars
app.engine('handlebars', exphbs.engine())
app.set('view engine', 'handlebars')


app.use(
    express.urlencoded({
        extended: true
    })
)

app.use(express.json())

app.use(express.static('public'))


//rotas 
app.get('/users/add', (req, res) => {
    res.render('userform')
    })
    
    app.post('/users/save', (req, res) => {
    const name = req.body.name
    const marca = req.body.marca
    const potencia = req.body.potencia
    const cor = req.body.cor
    const ano = req.body.ano
    const user = { name: name, marca: marca, potencia: potencia, cor: cor, ano: ano}
    res.render('viewuser', { user: user })
    
    })
    //Senha
    const usuario = {
        login: 'dyego',
        senha: 1234
    }

app.get('/', (req, res) => {
    res.render('login')
})

var auth = false

app.post('/user/login', (req,res) => {
    const login = req.body.login
    const senha = req.body.senha
    let message = ""

    if(login == usuario.login && senha == usuario.senha){
        auth = true
        message = "Usuário logado com Sucesso!"
        res.render('home', { usuario: usuario, auth, message})
    }
    else {
        auth = false
        message = "Erro!"
        res.render('login', { auth,message })
    }
})
//pagina 404
app.use(function(req, res, next){
    res.status(404).render('erro404')
})

//Sevidor
app.listen(port, () => {
    console.log('Servidor online em localhost:3000')
  })