const express = require('express');
const exphbs  = require('express-handlebars');
const app = express();
const PORT = 3000;

// Configuração do Handlebars
app.engine('handlebars',exphbs.engine());
app.set('view engine', 'handlebars');

app.use(
    express.urlencoded({
        extended: true
    })
)
app.use(express.json())

app.use(express.static('public'))

app.get('/',(req, res) => {
    res.render('home');
})


app.listen(PORT, () => {
    console.log(`Meu servidor está rodando na porta ${PORT}`);
})

/*app.listem(port, () => {
    console.log('Server Started')
})*/

app.get('/users/add', (req, res) => {
    res.render('userform')
    })
    
    app.post('/users/save', (req, res) => {
    const name = req.body.name
    const age = req.body.age
    
    const user = { name: name, age: age }
    res.render('viewuser', { user: user })
    
    })