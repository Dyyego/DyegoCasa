const express = require('express');
const app = express();

app.set('view engine', 'ejs'); 
app.set('views', './views'); 



app.set('views', './views');


app.get('/', (req, res) => {
  res.render('index');
});


app.post('/add-product', (req, res) => {
  res.render('products', {});
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`server: ${PORT}`);
});
